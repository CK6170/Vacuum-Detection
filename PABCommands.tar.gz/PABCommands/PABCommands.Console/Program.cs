using System;
using System.Linq;
using System.Text;

namespace PABCommands.Console
{
    internal static class Program
    {
        static void Main()
        {
            System.Console.WriteLine("=== PAB Command Builder Console Application ===");
            System.Console.WriteLine();

            while (true)
            {
                System.Console.WriteLine("Choose an option:");
                System.Console.WriteLine("1. Build Opcode Command");
                System.Console.WriteLine("2. Generate Leopard Sequence");
                System.Console.WriteLine("3. Exit");
                System.Console.Write("Enter choice (1-3): ");

                string? choice = System.Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        BuildOpcodeCommandInteractive();
                        break;
                    case "2":
                        GenerateLeopardSequenceInteractive();
                        break;
                    case "3":
                        return;
                    default:
                        System.Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }

                System.Console.WriteLine();
                System.Console.WriteLine("Press any key to continue...");
                System.Console.ReadKey();
                System.Console.Clear();
            }
        }

        static void BuildOpcodeCommandInteractive()
        {
            System.Console.WriteLine("\n=== Build Opcode Command ===");

            // Required fields
            System.Console.Write("Enter PAB Port Serial Number: ");
            if (!ushort.TryParse(System.Console.ReadLine(), out ushort pabPortSerialNumber))
            {
                System.Console.WriteLine("Invalid PAB Port Serial Number. Using default: 0");
                pabPortSerialNumber = 0;
            }

            System.Console.Write("Enter Leopard Sequence (hex, e.g., '01 02 03' or '010203'): ");
            string? leopardSeqInput = System.Console.ReadLine();
            byte[] leopardSequence = ParseHexString(leopardSeqInput ?? "");
            
            if (leopardSequence.Length == 0)
            {
                System.Console.WriteLine("Invalid or empty Leopard Sequence. Using default: [0x01, 0x02, 0x03]");
                leopardSequence = new byte[] { 0x01, 0x02, 0x03 };
            }

            // Optional fields
            System.Console.Write("Enter OpCode (default: 1): ");
            ushort opCode = ushort.TryParse(System.Console.ReadLine(), out ushort oc) ? oc : (ushort)1;

            System.Console.Write("Enter Sequence Number (default: 0): ");
            ushort sequenceNumber = ushort.TryParse(System.Console.ReadLine(), out ushort sn) ? sn : (ushort)0;

            System.Console.Write("Enter Timestamp (default: 0): ");
            uint timestamp = uint.TryParse(System.Console.ReadLine(), out uint ts) ? ts : 0u;

            System.Console.Write("Enter Leopard Sequence Number (default: 0): ");
            uint leopardSequenceNumber = uint.TryParse(System.Console.ReadLine(), out uint lsn) ? lsn : 0u;

            // Build command
            byte[] result = CommandBuilder.BuildOpcodeCommand(pabPortSerialNumber, leopardSequence, opCode, sequenceNumber, timestamp, leopardSequenceNumber);

            System.Console.WriteLine("\n=== Generated Opcode Command ===");
            DisplayResult(result);
        }

        static void GenerateLeopardSequenceInteractive()
        {
            System.Console.WriteLine("\n=== Generate Leopard Sequence ===");
            System.Console.Write("Enter command (e.g., 'A' or 'AB'): ");
            string command = System.Console.ReadLine()?.Trim() ?? "";

            if (string.IsNullOrEmpty(command))
            {
                System.Console.WriteLine("No command entered. Using default: 'A'");
                command = "A";
            }

            char id = command.Length > 0 ? command[0] : 'A';
            char cmd = command.Length > 1 ? command[1] : id;

            byte[] leopardSequence = CommandBuilder.BuildCommand(id, cmd);

            System.Console.WriteLine("\n=== Generated Leopard Sequence ===");
            DisplayResult(leopardSequence);
        }

        static byte[] ParseHexString(string hex)
        {
            if (string.IsNullOrWhiteSpace(hex))
                return new byte[0];

            // Remove spaces and common separators
            hex = hex.Replace(" ", "").Replace("-", "").Replace("0x", "");

            // Ensure even length
            if (hex.Length % 2 != 0)
                hex = "0" + hex;

            try
            {
                return Enumerable.Range(0, hex.Length)
                    .Where(x => x % 2 == 0)
                    .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
                    .ToArray();
            }
            catch
            {
                return new byte[0];
            }
        }

        static void DisplayResult(byte[] data)
        {
            System.Console.WriteLine($"Length: {data.Length} bytes");
            System.Console.WriteLine($"Hex (with spaces): {BitConverter.ToString(data).Replace("-", " ")}");
            System.Console.WriteLine($"Hex (compact): {BitConverter.ToString(data).Replace("-", "")}");
            System.Console.WriteLine($"Byte array: [{string.Join(", ", data.Select(b => $"0x{b:X2}"))}]");
            System.Console.WriteLine($"Decimal values: [{string.Join(", ", data)}]");
        }
    }
}