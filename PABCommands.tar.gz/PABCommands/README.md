# PAB Commands

A C# application suite for building PAB (Protocol Analysis Board) commands with CRC16 checksums and Leopard sequence generation.

## Features

- **Build Opcode Commands**: Create complete opcode command packets with required and optional parameters
- **Generate Leopard Sequences**: Create Leopard sequences with CRC16 checksums from command inputs
- **Multiple Interfaces**: Both console and WinForms applications available

## Projects

### PABCommands.Console
A console application that provides an interactive interface for:
- Building opcode commands
- Generating Leopard sequences
- Cross-platform compatible (Windows, Linux, macOS)

### PABCommands.WinForms
A Windows Forms application with a graphical user interface for:
- User-friendly input forms
- Real-time command generation
- Visual result display
- Windows only

## Building the Project

### Prerequisites
- .NET 8.0 SDK or later

### Build Instructions

#### Console Application (Cross-platform)
```bash
dotnet build PABCommands.Console/PABCommands.Console.csproj
dotnet run --project PABCommands.Console/PABCommands.Console.csproj
```

#### WinForms Application (Windows only)
```bash
dotnet build PABCommands.WinForms/PABCommands.WinForms.csproj
dotnet run --project PABCommands.WinForms/PABCommands.WinForms.csproj
```

#### Build All Projects
```bash
dotnet build PABCommands.sln
```

## Usage

### Required Parameters
- **PAB Port Serial Number**: A 16-bit unsigned integer (0-65535)
- **Leopard Sequence**: Hexadecimal byte sequence (e.g., "01 02 03" or "010203")

### Optional Parameters (with defaults)
- **OpCode**: Operation code (default: 1)
- **Sequence Number**: Packet sequence number (default: 0)
- **Timestamp**: Unix timestamp (default: 0)
- **Leopard Sequence Number**: Leopard sequence identifier (default: 0)

### Leopard Sequence Generation
Enter a command (e.g., "A" or "AB") to generate a Leopard sequence with:
- Command packet structure
- CRC16 checksum calculation
- Proper termination byte (0x0D)

## Command Structure

### Opcode Command Format
```
[S][K][Length(2)][Reserved(2)][Checksum(2)][SequenceNumber(2)][OpCode(2)][PABPortSerialNumber(2)][Timestamp(4)][LeopardSequenceNumber(4)][LeopardSequence...]
```

### Leopard Sequence Format
```
[0][ID][Command][CRC16(2)][0x0D]
```

## Examples

### Console Application Example
```
Choose an option:
1. Build Opcode Command
2. Generate Leopard Sequence
3. Exit
Enter choice (1-3): 2

=== Generate Leopard Sequence ===
Enter command (e.g., 'A' or 'AB'): A

=== Generated Leopard Sequence ===
Length: 6 bytes
Hex (with spaces): 30 41 41 A3 BD 0D
Hex (compact): 304141A3BD0D
Byte array: [0x30, 0x41, 0x41, 0xA3, 0xBD, 0x0D]
Decimal values: [48, 65, 65, 163, 189, 13]
```

## Technical Details

### CRC16 Calculation
- Uses polynomial 0x8810
- 16-bit checksum with bit shifting and XOR operations
- Big-endian byte order

### Checksum Calculation
- Sum of all bytes with logical NOT operation
- Used for opcode command integrity verification

## License

This project is provided as-is for educational and development purposes.