using System;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PABCommands.WinForms
{
    public partial class MainForm : Form
    {
        private TextBox txtPabPortSerialNumber;
        private TextBox txtLeopardSequence;
        private TextBox txtOpCode;
        private TextBox txtSequenceNumber;
        private TextBox txtTimestamp;
        private TextBox txtLeopardSequenceNumber;
        private TextBox txtLeopardCommand;
        private TextBox txtResult;
        private Button btnBuildOpcodeCommand;
        private Button btnGenerateLeopardSequence;
        private Button btnClear;
        private Label lblResult;

        public MainForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Form properties
            this.Text = "PAB Command Builder";
            this.Size = new System.Drawing.Size(800, 700);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // Required fields group
            var grpRequired = new GroupBox
            {
                Text = "Required Fields",
                Location = new System.Drawing.Point(20, 20),
                Size = new System.Drawing.Size(360, 100)
            };

            var lblPabPort = new Label
            {
                Text = "PAB Port Serial Number:",
                Location = new System.Drawing.Point(10, 25),
                Size = new System.Drawing.Size(150, 20)
            };
            txtPabPortSerialNumber = new TextBox
            {
                Location = new System.Drawing.Point(170, 23),
                Size = new System.Drawing.Size(170, 20)
            };

            var lblLeopardSeq = new Label
            {
                Text = "Leopard Sequence (hex):",
                Location = new System.Drawing.Point(10, 55),
                Size = new System.Drawing.Size(150, 20)
            };
            txtLeopardSequence = new TextBox
            {
                Location = new System.Drawing.Point(170, 53),
                Size = new System.Drawing.Size(170, 20),
                PlaceholderText = "e.g., 01 02 03 or 010203"
            };

            grpRequired.Controls.AddRange(new Control[] { lblPabPort, txtPabPortSerialNumber, lblLeopardSeq, txtLeopardSequence });

            // Optional fields group
            var grpOptional = new GroupBox
            {
                Text = "Optional Fields (defaults will be used if empty)",
                Location = new System.Drawing.Point(400, 20),
                Size = new System.Drawing.Size(360, 160)
            };

            var lblOpCode = new Label
            {
                Text = "OpCode (default: 1):",
                Location = new System.Drawing.Point(10, 25),
                Size = new System.Drawing.Size(150, 20)
            };
            txtOpCode = new TextBox
            {
                Location = new System.Drawing.Point(170, 23),
                Size = new System.Drawing.Size(170, 20)
            };

            var lblSeqNum = new Label
            {
                Text = "Sequence Number (default: 0):",
                Location = new System.Drawing.Point(10, 55),
                Size = new System.Drawing.Size(150, 20)
            };
            txtSequenceNumber = new TextBox
            {
                Location = new System.Drawing.Point(170, 53),
                Size = new System.Drawing.Size(170, 20)
            };

            var lblTimestamp = new Label
            {
                Text = "Timestamp (default: 0):",
                Location = new System.Drawing.Point(10, 85),
                Size = new System.Drawing.Size(150, 20)
            };
            txtTimestamp = new TextBox
            {
                Location = new System.Drawing.Point(170, 83),
                Size = new System.Drawing.Size(170, 20)
            };

            var lblLeopardSeqNum = new Label
            {
                Text = "Leopard Seq Number (default: 0):",
                Location = new System.Drawing.Point(10, 115),
                Size = new System.Drawing.Size(150, 20)
            };
            txtLeopardSequenceNumber = new TextBox
            {
                Location = new System.Drawing.Point(170, 113),
                Size = new System.Drawing.Size(170, 20)
            };

            grpOptional.Controls.AddRange(new Control[] { lblOpCode, txtOpCode, lblSeqNum, txtSequenceNumber, lblTimestamp, txtTimestamp, lblLeopardSeqNum, txtLeopardSequenceNumber });

            // Leopard sequence generation group
            var grpLeopard = new GroupBox
            {
                Text = "Generate Leopard Sequence",
                Location = new System.Drawing.Point(20, 140),
                Size = new System.Drawing.Size(360, 80)
            };

            var lblLeopardCmd = new Label
            {
                Text = "Command:",
                Location = new System.Drawing.Point(10, 25),
                Size = new System.Drawing.Size(70, 20)
            };
            txtLeopardCommand = new TextBox
            {
                Location = new System.Drawing.Point(90, 23),
                Size = new System.Drawing.Size(100, 20),
                PlaceholderText = "e.g., A"
            };

            btnGenerateLeopardSequence = new Button
            {
                Text = "Generate Leopard Sequence",
                Location = new System.Drawing.Point(200, 20),
                Size = new System.Drawing.Size(150, 30)
            };
            btnGenerateLeopardSequence.Click += BtnGenerateLeopardSequence_Click;

            grpLeopard.Controls.AddRange(new Control[] { lblLeopardCmd, txtLeopardCommand, btnGenerateLeopardSequence });

            // Buttons
            btnBuildOpcodeCommand = new Button
            {
                Text = "Build Opcode Command",
                Location = new System.Drawing.Point(20, 240),
                Size = new System.Drawing.Size(150, 40),
                BackColor = System.Drawing.Color.LightBlue
            };
            btnBuildOpcodeCommand.Click += BtnBuildOpcodeCommand_Click;

            btnClear = new Button
            {
                Text = "Clear All",
                Location = new System.Drawing.Point(190, 240),
                Size = new System.Drawing.Size(100, 40)
            };
            btnClear.Click += BtnClear_Click;

            // Result section
            lblResult = new Label
            {
                Text = "Generated Command (Hex):",
                Location = new System.Drawing.Point(20, 300),
                Size = new System.Drawing.Size(200, 20)
            };

            txtResult = new TextBox
            {
                Location = new System.Drawing.Point(20, 330),
                Size = new System.Drawing.Size(740, 320),
                Multiline = true,
                ScrollBars = ScrollBars.Both,
                ReadOnly = true,
                Font = new System.Drawing.Font("Consolas", 10)
            };

            // Add controls to form
            this.Controls.AddRange(new Control[] { 
                grpRequired, grpOptional, grpLeopard, 
                btnBuildOpcodeCommand, btnClear, 
                lblResult, txtResult 
            });

            this.ResumeLayout();
        }

        private void BtnBuildOpcodeCommand_Click(object sender, EventArgs e)
        {
            try
            {
                // Parse required fields
                if (!ushort.TryParse(txtPabPortSerialNumber.Text, out ushort pabPortSerialNumber))
                {
                    MessageBox.Show("Please enter a valid PAB Port Serial Number (0-65535)", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                byte[] leopardSequence = ParseHexString(txtLeopardSequence.Text);
                if (leopardSequence.Length == 0)
                {
                    MessageBox.Show("Please enter a valid Leopard Sequence in hex format", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Parse optional fields with defaults
                ushort opCode = string.IsNullOrWhiteSpace(txtOpCode.Text) ? (ushort)1 : 
                    ushort.TryParse(txtOpCode.Text, out ushort oc) ? oc : (ushort)1;

                ushort sequenceNumber = string.IsNullOrWhiteSpace(txtSequenceNumber.Text) ? (ushort)0 : 
                    ushort.TryParse(txtSequenceNumber.Text, out ushort sn) ? sn : (ushort)0;

                uint timestamp = string.IsNullOrWhiteSpace(txtTimestamp.Text) ? 0u : 
                    uint.TryParse(txtTimestamp.Text, out uint ts) ? ts : 0u;

                uint leopardSequenceNumber = string.IsNullOrWhiteSpace(txtLeopardSequenceNumber.Text) ? 0u : 
                    uint.TryParse(txtLeopardSequenceNumber.Text, out uint lsn) ? lsn : 0u;

                // Build the command
                byte[] result = CommandBuilder.BuildOpcodeCommand(pabPortSerialNumber, leopardSequence, opCode, sequenceNumber, timestamp, leopardSequenceNumber);

                // Display result
                DisplayResult(result, "Opcode Command");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error building command: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnGenerateLeopardSequence_Click(object sender, EventArgs e)
        {
            try
            {
                string command = txtLeopardCommand.Text.Trim();
                if (string.IsNullOrEmpty(command))
                {
                    MessageBox.Show("Please enter a command", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                // Generate leopard sequence using BuildCommand
                char id = command.Length > 0 ? command[0] : 'A';
                char cmd = command.Length > 1 ? command[1] : id;
                
                byte[] leopardSequence = CommandBuilder.BuildCommand(id, cmd);
                
                // Display the generated sequence in the leopard sequence field
                txtLeopardSequence.Text = BitConverter.ToString(leopardSequence).Replace("-", " ");
                
                // Also display in result area
                DisplayResult(leopardSequence, "Generated Leopard Sequence");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error generating leopard sequence: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void BtnClear_Click(object sender, EventArgs e)
        {
            txtPabPortSerialNumber.Clear();
            txtLeopardSequence.Clear();
            txtOpCode.Clear();
            txtSequenceNumber.Clear();
            txtTimestamp.Clear();
            txtLeopardSequenceNumber.Clear();
            txtLeopardCommand.Clear();
            txtResult.Clear();
        }

        private byte[] ParseHexString(string hex)
        {
            if (string.IsNullOrWhiteSpace(hex))
                return new byte[0];

            // Remove spaces and common separators
            hex = hex.Replace(" ", "").Replace("-", "").Replace("0x", "");

            // Ensure even length
            if (hex.Length % 2 != 0)
                hex = "0" + hex;

            try
            {
                return Enumerable.Range(0, hex.Length)
                    .Where(x => x % 2 == 0)
                    .Select(x => Convert.ToByte(hex.Substring(x, 2), 16))
                    .ToArray();
            }
            catch
            {
                return new byte[0];
            }
        }

        private void DisplayResult(byte[] data, string title)
        {
            var sb = new StringBuilder();
            sb.AppendLine($"=== {title} ===");
            sb.AppendLine($"Length: {data.Length} bytes");
            sb.AppendLine();

            // Hex representation
            sb.AppendLine("Hex (with spaces):");
            sb.AppendLine(BitConverter.ToString(data).Replace("-", " "));
            sb.AppendLine();

            // Hex representation (no spaces)
            sb.AppendLine("Hex (compact):");
            sb.AppendLine(BitConverter.ToString(data).Replace("-", ""));
            sb.AppendLine();

            // Byte array representation
            sb.AppendLine("Byte array:");
            sb.AppendLine($"[{string.Join(", ", data.Select(b => $"0x{b:X2}"))}]");
            sb.AppendLine();

            // Decimal representation
            sb.AppendLine("Decimal values:");
            sb.AppendLine($"[{string.Join(", ", data)}]");
            sb.AppendLine();

            txtResult.Text = sb.ToString();
        }
    }
}