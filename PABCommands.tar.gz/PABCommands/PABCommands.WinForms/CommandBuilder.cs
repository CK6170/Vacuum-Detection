using System;

namespace PABCommands.WinForms
{
    public static class CommandBuilder
    {
        /// <summary>
        /// Builds a command with CRC16 checksum for Leopard sequence generation
        /// </summary>
        /// <param name="ID">Command ID character</param>
        /// <param name="command">Command character</param>
        /// <returns>Command packet with CRC16 and terminator</returns>
        public static byte[] BuildCommand(char ID, char command)
        {
            byte[] packet = [(byte)'0', (byte)ID, (byte)command];
            ushort crc = CalcCRC16(packet);
            byte[] crcBytes = BitConverter.GetBytes(crc);
            Array.Reverse(crcBytes);
            return [.. packet, .. crcBytes, 0x0D];
        }

        /// <summary>
        /// Calculates CRC16 checksum using polynomial 0x8810
        /// </summary>
        /// <param name="data">Data to calculate checksum for</param>
        /// <returns>16-bit CRC checksum</returns>
        private static ushort CalcCRC16(byte[] data)
        {
            ushort cs = 0;
            foreach (byte b in data)
            {
                cs ^= (ushort)(b << 8);
                for (int i = 0; i < 8; i++)
                {
                    ushort carry = (ushort)(cs & 0x8000);
                    if (carry != 0)
                    {
                        carry = 1;
                        cs ^= 0x8810;
                    }
                    cs = (ushort)((cs << 1) + carry);
                }
            }
            return cs;
        }

        /// <summary>
        /// Builds a complete opcode command packet
        /// </summary>
        /// <param name="pabPortSerialNumber">PAB port serial number</param>
        /// <param name="leopardSequence">Leopard sequence bytes</param>
        /// <param name="opCode">Operation code (default: 1)</param>
        /// <param name="sequenceNumber">Sequence number (default: 0)</param>
        /// <param name="timestamp">Timestamp (default: 0)</param>
        /// <param name="leopardSequenceNumber">Leopard sequence number (default: 0)</param>
        /// <returns>Complete opcode command packet</returns>
        public static byte[] BuildOpcodeCommand(ushort pabPortSerialNumber, byte[] leopardSequence,
            ushort opCode = 1, ushort sequenceNumber = 0, uint timestamp = 0, uint leopardSequenceNumber = 0)
        {
            byte[] command = [(byte)'S', (byte)'K', 0, 0, 0, 0, 0, 0,
                ..BitConverter.GetBytes(sequenceNumber),
                ..BitConverter.GetBytes(opCode),
                ..BitConverter.GetBytes(pabPortSerialNumber),
                ..BitConverter.GetBytes(timestamp),
                ..BitConverter.GetBytes(leopardSequenceNumber),
                ..leopardSequence];
            
            // Calculate length
            ushort length = (ushort)command.Length;
            command[2] = (byte)(length & 0xFF);
            command[3] = (byte)((length >> 8) & 0xFF);
            
            // Calculate checksum: all bytes except checksum (bytes 6–7)
            ushort checksum = CalculateChecksum(command);
            command[6] = (byte)(checksum & 0xFF);
            command[7] = (byte)((checksum >> 8) & 0xFF);

            return command;
        }

        /// <summary>
        /// Calculates checksum using logical NOT of sum
        /// </summary>
        /// <param name="data">Data to calculate checksum for</param>
        /// <returns>Checksum value</returns>
        private static ushort CalculateChecksum(byte[] data)
        {
            int sum = 0;
            for (int i = 0; i < data.Length; i++)
            {
                sum += data[i];
            }
            return (ushort)(~sum); // Logic NOT
        }
    }
}